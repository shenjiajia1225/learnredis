#!/bin/sh
cd stnl3
rm -f sentinel.log
cp sentinel.conf.bak sentinel.conf
./redis-sentinel3 sentinel.conf &

