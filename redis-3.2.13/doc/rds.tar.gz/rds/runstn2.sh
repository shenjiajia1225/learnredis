#!/bin/sh
cd stnl2
rm -f sentinel.log
cp sentinel.conf.bak sentinel.conf
./redis-sentinel2 sentinel.conf &

