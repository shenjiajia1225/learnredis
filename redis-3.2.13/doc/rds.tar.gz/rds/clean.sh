#!/bin/sh

cd rds1
rm -f redis-server* *.rdb *.log
cd ..

cd rds2
rm -f redis-server* *.rdb *.log
cd ..

cd rds3
rm -f redis-server* *.rdb *.log
cd ..

cd stnl1
rm -f redis-sentinel* *.log
cd ..

cd stnl2
rm -f redis-sentinel* *.log
cd ..

cd stnl3
rm -f redis-sentinel* *.log
cd ..

rm -f redis-cli
