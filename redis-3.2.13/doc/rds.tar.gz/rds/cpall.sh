#!/bin/sh

cp ~/learnredis/redis-3.2.13/src/redis-server -f ./rds1/redis-server1
cp ~/learnredis/redis-3.2.13/src/redis-server -f ./rds2/redis-server2
cp ~/learnredis/redis-3.2.13/src/redis-server -f ./rds3/redis-server3

cp ~/learnredis/redis-3.2.13/src/redis-cli ./

cp ~/learnredis/redis-3.2.13/src/redis-sentinel -f ./stnl1/redis-sentinel1
cp ~/learnredis/redis-3.2.13/src/redis-sentinel -f ./stnl2/redis-sentinel2
cp ~/learnredis/redis-3.2.13/src/redis-sentinel -f ./stnl3/redis-sentinel3

