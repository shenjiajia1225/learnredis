#!/bin/sh
cd stnl1
rm -f sentinel.log
cp sentinel.conf.bak sentinel.conf
./redis-sentinel1 sentinel.conf &

