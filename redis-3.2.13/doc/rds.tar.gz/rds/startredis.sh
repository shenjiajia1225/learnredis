#!/bin/sh

cd rds1
rm -f redis.conf
rm -f runlog.log
cp redis.conf.bak redis.conf
./redis-server1 redis.conf &
cd ..

cd rds2
rm -f redis.conf
rm -f runlog.log
cp redis.conf.bak redis.conf
./redis-server2 redis.conf &
cd ..

cd rds3
rm -f redis.conf
rm -f runlog.log
cp redis.conf.bak redis.conf
./redis-server3 redis.conf &
cd ..


