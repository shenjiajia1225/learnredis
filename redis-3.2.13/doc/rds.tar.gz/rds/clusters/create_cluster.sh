#!/bin/sh

rm -f redis-trib.rb
cp ../../learnredis/redis-3.2.13/src/redis-trib.rb ./
chmod +x redis-trib.rb
./redis-trib.rb test --replicas 1 127.0.0.1:6371 127.0.0.1:6372 127.0.0.1:6373 127.0.0.1:6381 127.0.0.1:6382 127.0.0.1:6383
#./redis-trib.rb create --replicas 1 127.0.0.1:6371 127.0.0.1:6372 127.0.0.1:6373 127.0.0.1:6381 127.0.0.1:6382 127.0.0.1:6383

