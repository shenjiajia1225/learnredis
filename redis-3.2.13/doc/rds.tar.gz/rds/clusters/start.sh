#!/bin/sh

cp ~/learnredis/redis-3.2.13/src/redis-server -f ./rdsA/redis-serverA
cp ~/learnredis/redis-3.2.13/src/redis-server -f ./rdsB/redis-serverB
cp ~/learnredis/redis-3.2.13/src/redis-server -f ./rdsC/redis-serverC
cp ~/learnredis/redis-3.2.13/src/redis-server -f ./rdsD/redis-serverD
cp ~/learnredis/redis-3.2.13/src/redis-server -f ./rdsA1/redis-serverA1
cp ~/learnredis/redis-3.2.13/src/redis-server -f ./rdsB1/redis-serverB1
cp ~/learnredis/redis-3.2.13/src/redis-server -f ./rdsC1/redis-serverC1
cp ~/learnredis/redis-3.2.13/src/redis-server -f ./rdsD1/redis-serverD1

cp ~/learnredis/redis-3.2.13/src/redis-cli ./

function kill_process()
{
    param1=$1
    MID=`ps -ef |grep -w $param1 |grep -v "grep" |awk '{print $2}'`
    echo "------------------"
    echo "stop $param1"
    if [ ! "$MID" == "" ]; then
        kill $MID
        echo "killed $param1 $MID"
    fi
}

kill_process redis-serverA1
kill_process redis-serverB1
kill_process redis-serverC1
kill_process redis-serverD1
kill_process redis-serverA
kill_process redis-serverB
kill_process redis-serverC
kill_process redis-serverD

cd rdsA
rm -f *.log *.rdb *.conf *.aof
cp redis.conf.bak redis.conf
./redis-serverA redis.conf &
cd ..

cd rdsB
rm -f *.log *.rdb *.conf *.aof
cp redis.conf.bak redis.conf
./redis-serverB redis.conf &
cd ..

cd rdsC
rm -f *.log *.rdb *.conf *.aof
cp redis.conf.bak redis.conf
./redis-serverC redis.conf &
cd ..

cd rdsD
rm -f *.log *.rdb *.conf *.aof
cp redis.conf.bak redis.conf
./redis-serverD redis.conf &
cd ..

cd rdsA1
rm -f *.log *.rdb *.conf *.aof
cp redis.conf.bak redis.conf
./redis-serverA1 redis.conf &
cd ..

cd rdsB1
rm -f *.log *.rdb *.conf *.aof
cp redis.conf.bak redis.conf
./redis-serverB1 redis.conf &
cd ..

cd rdsC1
rm -f *.log *.rdb *.conf *.aof
cp redis.conf.bak redis.conf
./redis-serverC1 redis.conf &
cd ..

cd rdsD1
rm -f *.log *.rdb *.conf *.aof
cp redis.conf.bak redis.conf
./redis-serverD1 redis.conf &
cd ..


