#!/bin/sh

function kill_process()
{
    param1=$1
    MID=`ps -ef |grep -w $param1 |grep -v "grep" |awk '{print $2}'`
    echo "------------------"
    echo "stop $param1"
    if [ ! "$MID" == "" ]; then
        kill $MID
        echo "killed $param1 $MID"
    fi
}

kill_process redis-serverA1
kill_process redis-serverB1
kill_process redis-serverC1
kill_process redis-serverD1
kill_process redis-serverA
kill_process redis-serverB
kill_process redis-serverC
kill_process redis-serverD


