#!/bin/sh

cd rdsA
rm -f *.log *.rdb *.conf *.aof redis-server*
cd ..

cd rdsB
rm -f *.log *.rdb *.conf *.aof redis-server*
cd ..

cd rdsC
rm -f *.log *.rdb *.conf *.aof redis-server*
cd ..

cd rdsD
rm -f *.log *.rdb *.conf *.aof redis-server*
cd ..

cd rdsA1
rm -f *.log *.rdb *.conf *.aof redis-server*
cd ..

cd rdsB1
rm -f *.log *.rdb *.conf *.aof redis-server*
cd ..

cd rdsC1
rm -f *.log *.rdb *.conf *.aof redis-server*
cd ..

cd rdsD1
rm -f *.log *.rdb *.conf *.aof redis-server*
cd ..





