#!/bin/sh

rm -f redis-trib.rb
cp ../../learnredis/redis-3.2.13/src/redis-trib.rb ./
chmod +x redis-trib.rb
./redis-trib.rb reshard 127.0.0.1:6371

