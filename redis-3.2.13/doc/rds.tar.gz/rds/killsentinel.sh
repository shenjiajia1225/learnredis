#!/bin/sh

RDSID=`ps -ef |grep -w sentinel |grep -v "grep" |awk '{print $2}'`
if [ ! "$RDSID" == "" ]; then
    echo "kill $RDSID"
    kill $RDSID
fi
